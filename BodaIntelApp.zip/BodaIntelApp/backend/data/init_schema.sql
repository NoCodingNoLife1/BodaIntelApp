-- BodaRoute Analytics Tables

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Table for tracking fuel audits
CREATE TABLE IF NOT EXISTS fuel_audits (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    rider_id TEXT NOT NULL,
    entry_date DATE NOT NULL,
    liters NUMERIC NOT NULL,
    cost_ugx NUMERIC NOT NULL,
    distance_km NUMERIC NOT NULL,
    station TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Note: The authentication will map automatically to the `auth.users` table, which is native to Supabase.
-- It does not need to be manually created.
