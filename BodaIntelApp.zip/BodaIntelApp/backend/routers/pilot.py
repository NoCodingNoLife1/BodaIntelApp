"""Pilot Program Management Router"""
import random
from fastapi import APIRouter
from sys import path as syspath
import os
syspath.insert(0, os.path.dirname(os.path.dirname(__file__)))
from models.schemas import PilotRider, PilotStats, RiderStatus

router = APIRouter()

SACCOS = ["Kampala Boda Union", "Northern Bypass SACCO", "Entebbe Road Riders",
          "Makindye Fleet Co.", "Kawempe Riders Coop"]

FIRST_NAMES = ["John","David","Moses","Emmanuel","Peter","Samuel","Joseph","Isaac","Daniel","Michael"]
LAST_NAMES  = ["Ouma","Ssali","Kato","Muwanguzi","Nkurunziza","Tumwine","Bogere","Ssemaganda"]

_PILOT_RIDERS: list[dict] = []

def _seed_riders():
    global _PILOT_RIDERS
    if _PILOT_RIDERS:
        return
    for i in range(1, 31):
        _PILOT_RIDERS.append({
            "rider_id":     f"PIL-{i:03d}",
            "name":         f"{random.choice(FIRST_NAMES)} {random.choice(LAST_NAMES)}",
            "phone":        f"+256 7{random.randint(0,9)}{random.randint(0,9)} {random.randint(100,999)} {random.randint(100,999)}",
            "sacco":        random.choice(SACCOS),
            "joined_date":  f"2026-0{random.randint(1,3)}-{random.randint(1,28):02d}",
            "status":       random.choice(["active","pilot","inactive"]),
            "trips_count":  random.randint(5, 120),
            "avg_fuel_kpl": round(random.gauss(38, 8), 1),
            "score":        round(random.gauss(68, 15), 1),
        })

@router.get("/riders")
async def list_riders(status: str = None, sacco: str = None):
    _seed_riders()
    riders = _PILOT_RIDERS
    if status:
        riders = [r for r in riders if r["status"] == status]
    if sacco:
        riders = [r for r in riders if r["sacco"] == sacco]
    return {"riders": riders, "total": len(riders)}

@router.post("/register")
async def register_rider(rider: PilotRider):
    _seed_riders()
    entry = rider.dict()
    _PILOT_RIDERS.append(entry)
    return {"message": "Rider registered", "rider_id": rider.rider_id}

@router.get("/stats", response_model=PilotStats)
async def program_stats():
    _seed_riders()
    active  = [r for r in _PILOT_RIDERS if r["status"] in ("active","pilot")]
    scores  = [r["score"] for r in active]
    kpls    = [r["avg_fuel_kpl"] for r in active]

    baseline_kpl  = 30.0
    fuel_saved    = sum(max(0, k - baseline_kpl) * r["trips_count"] * 0.08
                        for k, r in zip(kpls, active))
    cost_saved    = int(fuel_saved * 5200)
    top_rider     = max(active, key=lambda r: r["score"])["name"] if active else None

    leaderboard = sorted(active, key=lambda r: r["score"], reverse=True)[:10]

    return PilotStats(
        total_riders=len(_PILOT_RIDERS),
        active_riders=len(active),
        avg_score=round(sum(scores)/len(scores) if scores else 0, 1),
        fuel_saved_liters=round(fuel_saved, 1),
        cost_saved_ugx=cost_saved,
        top_rider=top_rider,
        leaderboard=[{
            "rank":  i+1,
            "name":  r["name"],
            "sacco": r["sacco"],
            "score": r["score"],
            "kpl":   r["avg_fuel_kpl"],
        } for i, r in enumerate(leaderboard)],
    )

@router.get("/saccos")
async def list_saccos():
    return {"saccos": SACCOS}
