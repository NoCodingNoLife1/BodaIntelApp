from fastapi import APIRouter, HTTPException, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel
from utils.supabase_client import supabase

router = APIRouter()
security = HTTPBearer()

class UserCreds(BaseModel):
    email: str
    password: str

@router.post("/signup")
async def signup(creds: UserCreds):
    if not supabase:
        raise HTTPException(status_code=500, detail="Supabase not configured")
    try:
        response = supabase.auth.sign_up({"email": creds.email, "password": creds.password})
        if response.user:
            return {"status": "success", "user_id": response.user.id}
        else:
            raise HTTPException(status_code=400, detail="Signup failed")
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.post("/login")
async def login(creds: UserCreds):
    if not supabase:
        raise HTTPException(status_code=500, detail="Supabase not configured")
    try:
        response = supabase.auth.sign_in_with_password({"email": creds.email, "password": creds.password})
        if response.session:
            return {"status": "success", "session": response.session.model_dump()}
        raise HTTPException(status_code=401, detail="Invalid login")
    except Exception as e:
        raise HTTPException(status_code=401, detail=str(e))

def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)):
    """Dependency map to check JWT token from HTTP Authorization header"""
    if not supabase:
        return {"id": "mock_user"} # Fallback if supabase isn't configured
    
    token = credentials.credentials
    try:
        # get_user() verifies the JWT against Supabase automatically using the API
        user_resp = supabase.auth.get_user(token)
        if user_resp and user_resp.user:
            return user_resp.user
        raise HTTPException(status_code=401, detail="Invalid or expired token")
    except Exception as e:
        raise HTTPException(status_code=401, detail=str(e))
