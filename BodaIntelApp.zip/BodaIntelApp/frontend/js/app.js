/* ─── BodaIntel Platform ── Frontend App ───────────────────────────────── */

const API = window.location.origin;

// ── THEME ─────────────────────────────────────────────────────────────────────
function toggleTheme() {
  const html = document.documentElement;
  const isDark = html.getAttribute("data-theme") !== "light";
  const next = isDark ? "light" : "dark";
  html.setAttribute("data-theme", next);
  localStorage.setItem("bi-theme", next);
  const btn = document.getElementById("theme-btn");
  if (btn) btn.textContent = next === "light" ? "🌙" : "☀️";
  updateMapTheme();
}

function applyTheme() {
  const saved = localStorage.getItem("bi-theme") || "dark";
  document.documentElement.setAttribute("data-theme", saved);
  const btn = document.getElementById("theme-btn");
  if (btn) btn.textContent = saved === "light" ? "🌙" : "☀️";
}

// ── AUTH ──────────────────────────────────────────────────────────────────────
function handleLogout() {
  localStorage.removeItem("bi-authed");
  localStorage.removeItem("bi-session");
  window.location.href = "/login";
}

function checkAuth() {
  if (window.location.pathname === "/login") return;
  const session = JSON.parse(localStorage.getItem("bi-session") || "null");
  if (!session || !session.access_token) {
    window.location.href = "/login";
  }
}
checkAuth();

// ── UTILITY ──────────────────────────────────────────────────────────────────

async function apiFetch(path, opts = {}) {
  try {
    const headers = { "Content-Type": "application/json" };
    const session = JSON.parse(localStorage.getItem("bi-session") || "null");
    if (session && session.access_token) {
        headers["Authorization"] = `Bearer ${session.access_token}`;
    }

    const r = await fetch(API + path, {
      headers: headers,
      ...opts,
    });
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    return await r.json();
  } catch (e) {
    toast("API Error: " + e.message);
    return null;
  }
}

function post(path, body) {
  return apiFetch(path, { method: "POST", body: JSON.stringify(body) });
}

function toast(msg, dur = 3500) {
  const el = document.getElementById("toast");
  el.textContent = msg;
  el.classList.add("show");
  setTimeout(() => el.classList.remove("show"), dur);
}

function hide(id) { document.getElementById(id)?.classList.add("hidden"); }
function show(id) { document.getElementById(id)?.classList.remove("hidden"); }

function fmt(n, dec = 1) { return Number(n).toFixed(dec); }
function fmtUGX(n) { return "UGX " + Math.round(n).toLocaleString(); }

// ── CLOCK ─────────────────────────────────────────────────────────────────────
function updateClock() {
  const now = new Date();
  const h = String(now.getHours()).padStart(2,"0");
  const m = String(now.getMinutes()).padStart(2,"0");
  const s = String(now.getSeconds()).padStart(2,"0");
  const el = document.getElementById("clock");
  if (el) el.textContent = `${h}:${m}:${s}`;
}
setInterval(updateClock, 1000);
updateClock();

// ── NAVIGATION ───────────────────────────────────────────────────────────────
const VIEW_TITLES = {
  dashboard:   "Overview Dashboard",
  routing:     "Incline-Aware Routing",
  jam:         "Kampala Jam Predictor",
  road:        "Accelerometer Road Quality",
  fuel:        "Fuel-to-Weight Optimizer",
  maintenance: "Predictive Maintenance AI",
  dem:         "Digital Elevation Model",
  audit:       "Fuel Audit Dashboard",
  pilot:       "Pilot Program",
};

function showView(name) {
  document.querySelectorAll(".view").forEach(v => v.classList.remove("active"));
  document.querySelectorAll(".nav-item").forEach(n => n.classList.remove("active"));
  const view = document.getElementById("view-" + name);
  if (view) view.classList.add("active");
  document.querySelector(`[data-view="${name}"]`)?.classList.add("active");
  document.getElementById("page-title").textContent = VIEW_TITLES[name] || name;

  // Lazy-load on first visit
  if (!view?._loaded) {
    if (name === "dashboard")   loadDashboard();
    if (name === "routing")     loadRoutingNodes();
    if (name === "jam")         loadJamAreas();
    if (name === "fuel")        loadBikes();
    if (name === "road")        loadRoadSim();
    if (name === "maintenance") loadFleetHealth();
    if (name === "audit")       loadAuditDashboard();
    if (name === "pilot")       loadPilot();
    if (view) view._loaded = true;
  }

  // Mobile close
  document.getElementById("sidebar").classList.remove("open");

  // Invalidate map size when routing view becomes visible
  if (name === "routing") {
    setTimeout(() => {
      if (_osmMap) { _osmMap.resize(); }
      else if (document.getElementById('osm-map')) initOSMMap();
    }, 150);
  }
}

function toggleSidebar() {
  document.getElementById("sidebar").classList.toggle("open");
}

// ── DASHBOARD ─────────────────────────────────────────────────────────────────
async function loadDashboard() {
  const heatmap = await apiFetch("/api/jam/heatmap?hour=8&dow=0");
  if (heatmap) renderJamHeatmapDashboard(heatmap.heatmap);
  renderFuelEffChart();
  renderRoadQualityChart();
}

function renderJamHeatmapDashboard(data) {
  const el = document.getElementById("jam-heatmap-chart");
  if (!el || !data) return;
  const items = data.slice(0, 20).sort((a,b) => b.level - a.level);
  const maxLevel = Math.max(...items.map(i => i.level));

  el.innerHTML = `<div style="display:flex;align-items:flex-end;gap:5px;height:120px;padding:0 4px">
    ${items.map(item => {
      const h = Math.round((item.level / maxLevel) * 100);
      const col = item.level > 0.75 ? "#E94560" : item.level > 0.5 ? "#F5A623" : item.level > 0.3 ? "#3B82F6" : "#2ECC71";
      return `<div title="${item.area}: ${item.label}" style="flex:1;height:${h}%;background:${col};border-radius:3px 3px 0 0;min-width:8px;opacity:.85;transition:opacity .2s;cursor:default" onmouseover="this.style.opacity=1" onmouseout="this.style.opacity=.85"></div>`;
    }).join("")}
  </div>
  <div style="display:flex;gap:16px;padding:10px 4px 0;font-size:10px;font-family:var(--mono);color:var(--muted)">
    <span style="color:#2ECC71">● Low</span>
    <span style="color:#3B82F6">● Moderate</span>
    <span style="color:#F5A623">● High</span>
    <span style="color:#E94560">● Gridlock</span>
    <span style="margin-left:auto">Morning peak · Mon</span>
  </div>`;
}

function renderFuelEffChart() {
  const el = document.getElementById("fuel-eff-chart");
  if (!el) return;
  const data = Array.from({length: 20}, (_,i) => ({ kpl: 25 + Math.random()*30 }));
  const max = Math.max(...data.map(d => d.kpl));
  el.innerHTML = `<div class="mini-bars">
    ${data.map(d => {
      const h = Math.round((d.kpl / max) * 100);
      const col = d.kpl > 42 ? "#2ECC71" : d.kpl > 32 ? "#F5A623" : "#E94560";
      return `<div class="mini-bar" style="height:${h}%;background:${col}" title="${fmt(d.kpl)} km/L"></div>`;
    }).join("")}
  </div>
  <div style="font-size:10px;color:var(--muted);font-family:var(--mono);padding-top:8px">Efficiency per rider · baseline 30 km/L</div>`;
}

function renderRoadQualityChart() {
  const el = document.getElementById("road-quality-chart");
  if (!el) return;
  const labels = ["Smooth","Moderate","Rough","Potholed"];
  const vals   = [35, 28, 22, 15];
  const cols   = ["#2ECC71","#3B82F6","#F5A623","#E94560"];
  const total  = vals.reduce((a,b) => a+b, 0);
  el.innerHTML = `<div style="display:flex;flex-direction:column;gap:8px;padding:4px 0">
    ${labels.map((l,i) => {
      const pct = Math.round(vals[i] / total * 100);
      return `<div>
        <div style="display:flex;justify-content:space-between;font-size:11px;margin-bottom:3px;font-family:var(--mono)">
          <span style="color:var(--text2)">${l}</span><span style="color:${cols[i]}">${pct}%</span>
        </div>
        <div style="height:6px;background:var(--bg3);border-radius:3px;overflow:hidden">
          <div style="width:${pct}%;height:100%;background:${cols[i]};border-radius:3px"></div>
        </div>
      </div>`;
    }).join("")}
  </div>`;
}

// ── ROUTING + OSM MAP ─────────────────────────────────────────────────────────

let _osmMap      = null;   // Mapbox map instance
let _routeLayers = [];     // All drawn route polylines
let _markerLayers= [];     // Start/end markers
let _nodeData    = {};     // name → {lat,lon,elevation}

// Route color palette per mode
const ROUTE_COLORS = {
  eco:            { color: '#2ECC71', label: '🌿 Eco',           dash: null },
  fastest:        { color: '#3B82F6', label: '⚡ Fastest',        dash: '8,5' },
  safest:         { color: '#A855F7', label: '🛡 Safest',         dash: '4,4' },
  incline_aware:  { color: '#F5A623', label: '⛰ Incline-Aware',  dash: '12,4' },
};

class MapboxLegendControl {
  constructor(html) { this.html = html; }
  onAdd(map) {
    this._map = map;
    this._container = document.createElement('div');
    this._container.className = 'mapboxgl-ctrl mapboxgl-ctrl-group';
    this._container.style.cssText = 'background:rgba(10,12,16,.88);border:1px solid #252930;border-radius:8px;padding:10px 14px;font-family:JetBrains Mono,monospace;font-size:11px;color:#D8DCE8;backdrop-filter:blur(8px);';
    this._container.innerHTML = this.html;
    return this._container;
  }
  onRemove() {
    this._container.parentNode.removeChild(this._container);
    this._map = undefined;
  }
}

function initOSMMap() {
  if (_osmMap) return;

  const isDark = document.documentElement.getAttribute('data-theme') !== 'light';

  mapboxgl.accessToken = 'pk.eyJ1IjoiZW1tYWRlcnJpY2siLCJhIjoiY21uaW80NjltMGVhejJvcXNzN2JzeWprciJ9.7H9SbTPJ_Kz56uDTx7_-Aw';
  _osmMap = new mapboxgl.Map({
    container: 'osm-map',
    style: isDark ? 'mapbox://styles/mapbox/dark-v11' : 'mapbox://styles/mapbox/light-v11',
    center: [32.5800, 0.3200],
    zoom: 12,
    attributionControl: false
  });
  _osmMap.addControl(new mapboxgl.NavigationControl());
  _osmMap.addControl(new mapboxgl.AttributionControl({ compact: true }));

  _osmMap._isDark = isDark;

  _osmMap.on('load', () => {
    // Add Kampala node markers
    Object.entries(_nodeData).forEach(([name, n]) => {
      const el = document.createElement('div');
      el.className = 'marker';
      el.style.width = '8px';
      el.style.height = '8px';
      el.style.backgroundColor = '#F5A623';
      el.style.borderRadius = '50%';
      el.style.opacity = '0.6';
      
      new mapboxgl.Marker(el)
        .setLngLat([n.lon, n.lat])
        .setPopup(new mapboxgl.Popup({ offset: 15 }).setText(name))
        .addTo(_osmMap);
    });
  });

  document.getElementById('map-status').textContent = `${Object.keys(_nodeData).length} nodes loaded`;
}

function updateMapTheme() {
  if (!_osmMap) return;
  const isDark = document.documentElement.getAttribute('data-theme') !== 'light';
  if (isDark === _osmMap._isDark) return;
  _osmMap.setStyle(isDark ? 'mapbox://styles/mapbox/dark-v11' : 'mapbox://styles/mapbox/light-v11');
  _osmMap._isDark = isDark;
}

function clearMapRoutes() {
  if (!_osmMap) return;
  _routeLayers.forEach(id => {
    if (_osmMap.getLayer(id)) _osmMap.removeLayer(id);
    if (_osmMap.getSource(id)) _osmMap.removeSource(id);
  });
  _markerLayers.forEach(m => m.remove());
  _routeLayers  = [];
  _markerLayers = [];
  document.getElementById('route-comparison').innerHTML = '';
  document.getElementById('route-map').innerHTML = '';
  hide('route-result');
}

function drawRouteOnMap(routeNodes, mode, isMain = true) {
  if (!_osmMap || !routeNodes.length) return;
  
  if (!_osmMap.isStyleLoaded()) {
    _osmMap.once('idle', () => drawRouteOnMap(routeNodes, mode, isMain));
    return;
  }
  
  const cfg   = ROUTE_COLORS[mode] || ROUTE_COLORS.eco;
  const coordinates = routeNodes.map(n => [n.lon, n.lat]);
  const routeId = 'route-' + Math.random().toString(36).substring(2, 9);
  
  _osmMap.addSource(routeId, {
    type: 'geojson',
    data: { type: 'Feature', geometry: { type: 'LineString', coordinates: coordinates } }
  });

  const dashArray = cfg.dash ? cfg.dash.split(',').map(Number) : undefined;
  
  _osmMap.addLayer({
    id: routeId,
    type: 'line',
    source: routeId,
    layout: { 'line-join': 'round', 'line-cap': 'round' },
    paint: {
      'line-color': cfg.color,
      'line-width': isMain ? 5 : 3,
      'line-opacity': isMain ? 0.92 : 0.6,
      ...(dashArray && { 'line-dasharray': dashArray })
    }
  });

  _routeLayers.push(routeId);

  if (isMain) {
    const startEl = document.createElement('div');
    startEl.style.cssText = 'width:14px;height:14px;background:#2ECC71;border:2px solid #fff;border-radius:50%;box-shadow:0 2px 8px rgba(0,0,0,.4)';
    const endEl = document.createElement('div');
    endEl.style.cssText = 'width:14px;height:14px;background:#E94560;border:2px solid #fff;border-radius:50%;box-shadow:0 2px 8px rgba(0,0,0,.4)';

    const sm = new mapboxgl.Marker({element: startEl})
      .setLngLat(coordinates[0])
      .setPopup(new mapboxgl.Popup({ offset: 15 }).setHTML(`<b>Start:</b> ${routeNodes[0].name}<br>Elev: ${Math.round(routeNodes[0].elevation)}m`))
      .addTo(_osmMap);
      
    const em = new mapboxgl.Marker({element: endEl})
      .setLngLat(coordinates[coordinates.length-1])
      .setPopup(new mapboxgl.Popup({ offset: 15 }).setHTML(`<b>End:</b> ${routeNodes[routeNodes.length-1].name}<br>Elev: ${Math.round(routeNodes[routeNodes.length-1].elevation)}m`))
      .addTo(_osmMap);

    _markerLayers.push(sm, em);

    const bounds = new mapboxgl.LngLatBounds(coordinates[0], coordinates[0]);
    for (const coord of coordinates) { bounds.extend(coord); }
    _osmMap.fitBounds(bounds, { padding: 40 });
    
    document.getElementById('map-status').textContent = `${cfg.label} · ${routeNodes.length} stops`;
  }
}

async function loadRoutingNodes() {
  const data = await apiFetch('/api/routing/nodes');
  if (!data) return;

  // Build node lookup from Kampala graph
  const allNodes = data.nodes;
  allNodes.forEach(name => {
    // Approximate coords — will be populated from route responses
    _nodeData[name] = { lat: 0.33, lon: 32.58, elevation: 1200 };
  });

  ['r-origin', 'r-dest'].forEach(id => {
    const sel = document.getElementById(id);
    if (!sel) return;
    sel.innerHTML = allNodes.map(n => `<option value="${n}">${n}</option>`).join('');
  });
  const dest = document.getElementById('r-dest');
  if (dest) dest.selectedIndex = 5;

  // Init map (needs DOM)
  setTimeout(() => {
    if (document.getElementById('osm-map')) initOSMMap();
  }, 100);
}

async function calculateRoute() {
  const body = {
    origin:          document.getElementById('r-origin').value,
    destination:     document.getElementById('r-dest').value,
    mode:            document.getElementById('r-mode').value,
    rider_weight_kg: +document.getElementById('r-rider-w').value,
    load_kg:         +document.getElementById('r-load').value,
    fuel_liters:     +document.getElementById('r-fuel').value,
  };
  toast('Calculating route…');
  clearMapRoutes();

  if (!_osmMap && document.getElementById('osm-map')) initOSMMap();

  const data = await post('/api/routing/calculate', body);
  if (!data) return;

  // Update node data with real coordinates from response
  data.route.forEach(n => { _nodeData[n.name] = n; });

  renderRouteResult(data);
  drawRouteOnMap(data.route, body.mode, true);
  renderRouteSteps(data.route);
}

async function calculateAllRoutes() {
  const origin = document.getElementById('r-origin').value;
  const dest   = document.getElementById('r-dest').value;
  const base   = {
    origin, destination: dest,
    rider_weight_kg: +document.getElementById('r-rider-w').value,
    load_kg:         +document.getElementById('r-load').value,
    fuel_liters:     +document.getElementById('r-fuel').value,
  };

  toast('Calculating all 4 routes…');
  clearMapRoutes();
  if (!_osmMap && document.getElementById('osm-map')) initOSMMap();

  const modes   = ['eco', 'fastest', 'safest', 'incline_aware'];
  const results = await Promise.all(modes.map(m => post('/api/routing/calculate', { ...base, mode: m })));

  const valid = results.map((r, i) => ({ mode: modes[i], data: r })).filter(x => x.data);

  // Draw all routes — first is "main" (fits bounds)
  valid.forEach((r, i) => {
    r.data.route.forEach(n => { _nodeData[n.name] = n; });
    drawRouteOnMap(r.data.route, r.mode, i === 0);
  });

  // Show comparison table
  renderComparisonTable(valid);

  // Show first route result
  if (valid[0]) {
    renderRouteResult(valid[0].data);
    renderRouteSteps(valid[0].data.route);
  }

  // Add legend to map
  addMapLegend(valid.map(r => r.mode));
}

function addMapLegend(modes) {
  if (!_osmMap || _osmMap._legend) return;
  const html = `<div style="font-weight:700;margin-bottom:6px;color:#F5A623">ROUTES</div>` +
      modes.map(m => {
        const c = ROUTE_COLORS[m];
        return `<div style="display:flex;align-items:center;gap:7px;margin-bottom:4px">
          <div style="width:24px;height:3px;background:${c.color};border-radius:2px"></div>
          <span>${c.label}</span>
        </div>`;
      }).join('');
  const legend = new MapboxLegendControl(html);
  _osmMap.addControl(legend, 'bottom-left');
  _osmMap._legend = legend;
}

function renderRouteSteps(nodes) {
  const el = document.getElementById('route-map');
  if (!el) return;
  el.innerHTML = `<div style="font-size:10px;color:var(--text2);font-family:var(--mono);margin-bottom:10px">
    ${nodes[0]?.name} → ${nodes[nodes.length-1]?.name} · ${nodes.length} stops
  </div>
  <div class="route-steps">
    ${nodes.map((n, i) => `
      ${i > 0 ? '<div class="step-connector"></div>' : ''}
      <div class="route-step">
        <div class="step-badge">${i+1}</div>
        <span class="step-name" style="font-size:11px">${n.name}</span>
        <span class="step-elev">${Math.round(n.elevation)}m</span>
        <span class="step-grade ${n.grade > 4 ? 'steep' : 'flat'}">${fmt(n.grade,1)}%</span>
      </div>`).join('')}
  </div>`;
}

function renderComparisonTable(routes) {
  const el = document.getElementById('route-comparison');
  if (!el) return;
  el.innerHTML = `<table class="fuel-table" style="margin-top:4px">
    <thead><tr>
      <th>Mode</th><th>Distance</th><th>Time</th><th>Fuel Cost</th>
      <th>Incline</th><th>Stops</th><th>CO₂ Saved</th>
    </tr></thead>
    <tbody>
      ${routes.map(r => {
        const c = ROUTE_COLORS[r.mode];
        const d = r.data;
        return `<tr>
          <td><span style="display:inline-flex;align-items:center;gap:7px">
            <span style="width:10px;height:10px;border-radius:50%;background:${c.color};display:inline-block"></span>
            ${c.label}
          </span></td>
          <td>${fmt(d.total_distance_km)} km</td>
          <td>${fmt(d.estimated_time_min)} min</td>
          <td style="color:var(--accent)">${fmtUGX(d.fuel_cost_ugx)}</td>
          <td style="color:${d.incline_score > 40 ? 'var(--accent2)' : 'var(--green)'}">${fmt(d.incline_score)}/100</td>
          <td>${d.route.length}</td>
          <td style="color:var(--green)">${fmt(d.co2_saved_g)} g</td>
        </tr>`;
      }).join('')}
    </tbody>
  </table>`;
}

function renderRouteResult(d) {
  show('route-result');
  document.getElementById('route-result').innerHTML = `
    <div class="result-grid">
      <div class="result-kv"><span class="rk">Distance</span><span class="rv">${fmt(d.total_distance_km)} km</span></div>
      <div class="result-kv"><span class="rk">Est. Time</span><span class="rv">${fmt(d.estimated_time_min)} min</span></div>
      <div class="result-kv"><span class="rk">Fuel Cost</span><span class="rv">${fmtUGX(d.fuel_cost_ugx)}</span></div>
      <div class="result-kv"><span class="rk">Incline Score</span><span class="rv ${d.incline_score > 40 ? 'red' : 'green'}">${fmt(d.incline_score)}/100</span></div>
      <div class="result-kv"><span class="rk">CO₂ Saved</span><span class="rv green">${fmt(d.co2_saved_g)} g</span></div>
      <div class="result-kv"><span class="rk">Stops</span><span class="rv">${d.route.length}</span></div>
    </div>
    <div class="recommendation">💡 ${d.recommendation}</div>`;
}


// ── JAM PREDICTOR ─────────────────────────────────────────────────────────────
async function loadJamAreas() {
  const data = await apiFetch("/api/jam/areas");
  if (!data) return;
  const sel = document.getElementById("j-area");
  if (sel) sel.innerHTML = data.areas.map(a => `<option value="${a}">${a}</option>`).join("");
}

async function predictJam() {
  const area = document.getElementById("j-area").value;
  const hour = +document.getElementById("j-hour").value;
  const dow  = +document.getElementById("j-day").value;
  toast("Predicting jam…");
  const data = await post("/api/jam/predict", { area, hour_of_day: hour, day_of_week: dow });
  if (!data) return;
  renderJamResult(data);
  loadWeeklyForecast(area);
}

function renderJamResult(d) {
  show("jam-result");
  const lvl   = d.congestion_level;
  const cls   = lvl < 0.3 ? "level-low" : lvl < 0.55 ? "level-mod" : lvl < 0.80 ? "level-high" : "level-grid";
  const col   = lvl < 0.3 ? "#2ECC71"   : lvl < 0.55 ? "#3B82F6"   : lvl < 0.80 ? "#F5A623"    : "#E94560";
  const pct   = Math.round(lvl * 100);
  document.getElementById("jam-result").innerHTML = `
    <div class="result-grid" style="grid-template-columns:repeat(3,1fr)">
      <div class="result-kv"><span class="rk">Area</span><span class="rv" style="font-size:14px">${d.area}</span></div>
      <div class="result-kv"><span class="rk">Avg Speed</span><span class="rv">${fmt(d.avg_speed_kmh)} km/h</span></div>
      <div class="result-kv"><span class="rk">Clears By</span><span class="rv" style="font-size:14px">${d.predicted_clear}</span></div>
    </div>
    <div class="congestion-meter">
      <div class="congestion-bar-wrap"><div class="congestion-bar-fill" style="width:${pct}%;background:${col}"></div></div>
      <span class="congestion-label-badge ${cls}">${d.label}</span>
      <span style="font-family:var(--mono);font-size:12px;color:var(--text2)">${pct}%</span>
    </div>
    <div style="display:flex;gap:10px;flex-wrap:wrap">
      ${d.hotspots.map((h,i) => `
        <div style="background:var(--bg3);border:1px solid var(--border);border-radius:6px;padding:8px 12px;font-family:var(--mono);font-size:11px">
          <div style="color:var(--text2);margin-bottom:2px">${h.label}</div>
          <div style="color:${h.severity > 0.7 ? "var(--accent2)" : "var(--accent)"}">Severity ${Math.round(h.severity*100)}%</div>
          <div style="color:var(--muted);font-size:10px">${h.lat.toFixed(4)}, ${h.lon.toFixed(4)}</div>
        </div>`).join("")}
    </div>`;
}

async function loadWeeklyForecast(area) {
  const data = await apiFetch(`/api/jam/weekly/${encodeURIComponent(area)}`);
  if (!data) return;
  show("jam-weekly");
  renderWeeklyHeatmap(data.forecast);
}

function renderWeeklyHeatmap(forecast) {
  const el = document.getElementById("jam-weekly");
  if (!el) return;
  const days  = ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"];
  const hours = [0,3,6,9,12,15,18,21];

  let html = `<div style="font-family:var(--mono);font-size:11px">
    <div style="color:var(--text2);margin-bottom:10px;font-size:12px">Weekly Congestion Forecast</div>
    <div style="display:grid;grid-template-columns:32px repeat(7,1fr);gap:3px;align-items:center">
      <div></div>
      ${days.map(d => `<div style="text-align:center;color:var(--muted);font-size:9px">${d}</div>`).join("")}
      ${hours.map(h => `
        <div style="color:var(--muted);font-size:9px;text-align:right;padding-right:6px">${String(h).padStart(2,"0")}</div>
        ${days.map((_,di) => {
          const entry = forecast.find(f => f.hour === h && f.day === days[di]);
          const lvl   = entry ? entry.level : 0;
          const col   = lvl < 0.3 ? "#2ECC71" : lvl < 0.55 ? "#3B82F6" : lvl < 0.80 ? "#F5A623" : "#E94560";
          return `<div style="height:22px;border-radius:3px;background:${col};opacity:${0.2 + lvl*0.8}" title="${days[di]} ${h}:00 — ${Math.round(lvl*100)}%"></div>`;
        }).join("")}
      `).join("")}
    </div>
  </div>`;
  el.innerHTML = html;
}

// ── ROAD QUALITY ─────────────────────────────────────────────────────────────
async function loadRoadSim() {
  const data = await apiFetch("/api/road-quality/simulate");
  if (!data) return;
  renderRoadQualitySim(data.segments);
}

function renderRoadQualitySim(segs) {
  const el = document.getElementById("road-map-sim");
  if (!el) return;
  const sorted = segs.sort((a,b) => b.rqi - a.rqi);
  el.innerHTML = `
    <div style="font-family:var(--mono);font-size:11px;color:var(--text2);margin-bottom:10px;padding-left:16px">
      Kampala Road Quality Map (Simulated) · ${segs.length} segments
    </div>
    <div class="rq-grid">
    ${sorted.map(s => {
      const col = s.rqi >= 80 ? "#2ECC71" : s.rqi >= 60 ? "#3B82F6" : s.rqi >= 35 ? "#F5A623" : "#E94560";
      const bg  = s.rqi >= 80 ? "rgba(46,204,113,.2)" : s.rqi >= 60 ? "rgba(59,130,246,.2)" : s.rqi >= 35 ? "rgba(245,166,35,.2)" : "rgba(233,69,96,.2)";
      return `<div class="rq-dot" style="background:${bg};color:${col}" title="${s.area}: RQI ${s.rqi} (${s.condition})">${Math.round(s.rqi)}</div>`;
    }).join("")}
    </div>
    <div style="display:flex;gap:16px;padding:0 16px 10px;font-size:10px;font-family:var(--mono);color:var(--muted)">
      <span style="color:#2ECC71">● Smooth (≥80)</span>
      <span style="color:#3B82F6">● Moderate (≥60)</span>
      <span style="color:#F5A623">● Rough (≥35)</span>
      <span style="color:#E94560">● Potholed (&lt;35)</span>
    </div>`;
}

async function analyzeRoad() {
  const body = {
    lat: +document.getElementById("rq-lat").value,
    lon: +document.getElementById("rq-lon").value,
    ax:  +document.getElementById("rq-ax").value,
    ay:  +document.getElementById("rq-ay").value,
    az:  +document.getElementById("rq-az").value,
    speed_kmh: +document.getElementById("rq-spd").value,
  };
  toast("Analyzing reading…");
  const data = await post("/api/road-quality/analyze", body);
  if (!data) return;
  const colMap = { smooth:"#2ECC71", moderate:"#3B82F6", rough:"#F5A623", potholed:"#E94560" };
  const col = colMap[data.condition] || "#F5A623";
  show("road-result");
  document.getElementById("road-result").innerHTML = `
    <div class="result-grid">
      <div class="result-kv"><span class="rk">RQI Score</span><span class="rv" style="color:${col}">${fmt(data.rqi)}/100</span></div>
      <div class="result-kv"><span class="rk">Condition</span><span class="rv" style="color:${col};font-size:16px;text-transform:capitalize">${data.condition}</span></div>
      <div class="result-kv"><span class="rk">Vibration</span><span class="rv">${fmt(data.vibration,3)} m/s²</span></div>
    </div>
    <div class="recommendation">📍 Segment <b>${data.segment}</b> — ${
      data.rqi >= 80 ? "Road is in excellent condition. No concern." :
      data.rqi >= 60 ? "Minor surface irregularities. Moderate caution advised." :
      data.rqi >= 35 ? "Rough road. Reduce speed and cargo for rider comfort." :
      "Severely potholed. Avoid if possible — high bike wear risk."
    }</div>`;
}

// ── FUEL OPTIMIZER ────────────────────────────────────────────────────────────
async function loadBikes() {
  const data = await apiFetch("/api/fuel/bikes");
  if (!data) return;
  const sel = document.getElementById("f-bike");
  if (sel) sel.innerHTML = data.bikes.map(b => `<option value="${b.model}">${b.model} (${b.engine_cc}cc · ${b.base_kpl}km/L)</option>`).join("");
}

async function optimizeFuel() {
  const body = {
    bike_model:      document.getElementById("f-bike").value,
    rider_weight_kg: +document.getElementById("f-rider-w").value,
    load_kg:         +document.getElementById("f-load").value,
    fuel_liters:     +document.getElementById("f-fuel").value,
    distance_km:     +document.getElementById("f-dist").value,
    incline_avg:     +document.getElementById("f-incline").value,
  };
  toast("Computing fuel model…");
  const data = await post("/api/fuel/optimize", body);
  if (!data) return;
  show("fuel-result");
  document.getElementById("fuel-result").innerHTML = `
    <div style="display:flex;align-items:center;gap:20px;margin-bottom:16px">
      <div class="grade-badge grade-${data.efficiency_grade}">${data.efficiency_grade}</div>
      <div>
        <div style="font-size:20px;font-weight:800">${fmt(data.range_km)} km range</div>
        <div style="color:var(--text2);font-size:12px;font-family:var(--mono)">Total weight: ${fmt(data.total_weight_kg)} kg</div>
      </div>
    </div>
    <div class="result-grid">
      <div class="result-kv"><span class="rk">Fuel:Weight Ratio</span><span class="rv">${data.fuel_to_weight_ratio.toFixed(4)} L/kg/100km</span></div>
      <div class="result-kv"><span class="rk">Cost per km</span><span class="rv">${fmtUGX(data.cost_per_km_ugx)}</span></div>
      <div class="result-kv"><span class="rk">Optimal Load</span><span class="rv green">${data.optimal_load_kg} kg</span></div>
    </div>
    <div class="recommendation">💡 ${data.savings_tip}</div>`;
}

// ── MAINTENANCE ───────────────────────────────────────────────────────────────
async function analyzeMaintenance() {
  const body = {
    bike_id:          document.getElementById("m-id").value,
    mileage_km:       +document.getElementById("m-km").value,
    last_service_km:  +document.getElementById("m-svc-km").value,
    engine_hours:     +document.getElementById("m-hours").value,
    avg_vibration:    +document.getElementById("m-vib").value,
    brake_wear_pct:   +document.getElementById("m-brake").value,
    chain_stretch_mm: +document.getElementById("m-chain").value,
    tire_pressure_f:  +document.getElementById("m-tyre-f").value,
    tire_pressure_r:  +document.getElementById("m-tyre-r").value,
    oil_level_pct:    +document.getElementById("m-oil").value,
  };
  toast("Running diagnostics…");
  const data = await post("/api/maintenance/analyze", body);
  if (!data) return;
  show("maint-result");

  const hcol = data.health_score >= 70 ? "#2ECC71" : data.health_score >= 40 ? "#F5A623" : "#E94560";
  document.getElementById("maint-result").innerHTML = `
    <div style="display:flex;align-items:center;gap:20px;margin-bottom:16px">
      <div style="font-size:38px;font-weight:800;color:${hcol}">${fmt(data.health_score)}<span style="font-size:16px;color:var(--text2)">/100</span></div>
      <div>
        <div style="font-weight:700;font-size:15px">Bike ${data.bike_id}</div>
        <div style="color:var(--text2);font-size:12px;font-family:var(--mono)">
          Next service: ${Math.round(data.next_service_km).toLocaleString()} km ·
          Failure risk: ${Math.round(data.predicted_failure_risk * 100)}%
        </div>
      </div>
    </div>
    <div class="alert-list">
      ${data.alerts.map(a => `
        <div class="alert-item ${a.urgency}">
          <div class="alert-dot"></div>
          <div class="alert-body">
            <div class="alert-comp">${a.component}</div>
            <div class="alert-msg">${a.message}${a.cost_est_ugx ? ` · Est. ${fmtUGX(a.cost_est_ugx)}` : ""}</div>
          </div>
          <span style="font-size:10px;font-family:var(--mono);color:var(--muted);text-transform:uppercase">${a.urgency}</span>
        </div>`).join("")}
    </div>`;
}

async function loadFleetHealth() {
  const data = await apiFetch("/api/maintenance/fleet-status");
  if (!data) return;
  const el = document.getElementById("fleet-health");
  if (!el) return;
  const bikes = data.fleet;
  el.innerHTML = `<div style="display:flex;flex-direction:column;gap:6px">
    ${bikes.slice(0,8).map(b => {
      const col = b.health >= 70 ? "#2ECC71" : b.health >= 40 ? "#F5A623" : "#E94560";
      return `<div style="display:flex;align-items:center;gap:10px;font-family:var(--mono);font-size:11px">
        <span style="color:var(--text2);width:72px">${b.bike_id}</span>
        <div style="flex:1;height:6px;background:var(--bg3);border-radius:3px;overflow:hidden">
          <div style="width:${b.health}%;height:100%;background:${col};border-radius:3px"></div>
        </div>
        <span style="color:${col};width:36px;text-align:right">${fmt(b.health)}</span>
        ${b.alerts > 0 ? `<span style="color:var(--accent2);font-size:10px">⚠ ${b.alerts}</span>` : `<span style="color:var(--green);font-size:10px">✓</span>`}
      </div>`;
    }).join("")}
  </div>`;
}

// ── DEM ───────────────────────────────────────────────────────────────────────
async function fetchDEM() {
  const lat1  = +document.getElementById("d-lat1").value;
  const lon1  = +document.getElementById("d-lon1").value;
  const lat2  = +document.getElementById("d-lat2").value;
  const lon2  = +document.getElementById("d-lon2").value;
  const steps = +document.getElementById("d-steps").value;
  toast("Fetching elevation profile…");
  const data = await apiFetch(`/api/dem/profile?lat1=${lat1}&lon1=${lon1}&lat2=${lat2}&lon2=${lon2}&steps=${steps}`);
  if (!data) return;
  show("dem-result");
  document.getElementById("dem-result").innerHTML = `
    <div class="result-grid">
      <div class="result-kv"><span class="rk">Min Elevation</span><span class="rv">${fmt(data.min_elevation)} m</span></div>
      <div class="result-kv"><span class="rk">Max Elevation</span><span class="rv">${fmt(data.max_elevation)} m</span></div>
      <div class="result-kv"><span class="rk">Total Climb</span><span class="rv red">↑ ${fmt(data.total_climb_m)} m</span></div>
      <div class="result-kv"><span class="rk">Total Descent</span><span class="rv green">↓ ${fmt(data.total_descent_m)} m</span></div>
      <div class="result-kv"><span class="rk">Avg Grade</span><span class="rv">${fmt(data.avg_grade)}%</span></div>
      <div class="result-kv"><span class="rk">Points</span><span class="rv">${data.points.length}</span></div>
    </div>`;
  renderDEMProfile(data.points);
}

function renderDEMProfile(points) {
  const el = document.getElementById("dem-chart");
  if (!el || !points.length) return;
  const W = el.clientWidth || 600, H = 200;
  const elevs   = points.map(p => p.elevation);
  const minE    = Math.min(...elevs), maxE = Math.max(...elevs);
  const padY    = 20, padX = 40;
  const innerW  = W - padX * 2, innerH = H - padY * 2;

  const xScale = i => padX + (i / (points.length - 1)) * innerW;
  const yScale = e => padY + innerH - ((e - minE) / ((maxE - minE) || 1)) * innerH;

  const pathD = points.map((p,i) => `${i === 0 ? "M" : "L"}${xScale(i)},${yScale(p.elevation)}`).join(" ");
  const fillD = `${pathD} L${xScale(points.length-1)},${padY+innerH} L${padX},${padY+innerH} Z`;

  const gradesColor = points.map(p => {
    if (p.grade > 6) return "#E94560";
    if (p.grade > 3) return "#F5A623";
    return "#2ECC71";
  });

  el.innerHTML = `<svg width="100%" height="${H}" viewBox="0 0 ${W} ${H}">
    <defs>
      <linearGradient id="demGrad" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stop-color="#F5A623" stop-opacity="0.3"/>
        <stop offset="100%" stop-color="#F5A623" stop-opacity="0.02"/>
      </linearGradient>
    </defs>
    <path d="${fillD}" fill="url(#demGrad)"/>
    <path d="${pathD}" fill="none" stroke="#F5A623" stroke-width="2" stroke-linejoin="round"/>
    ${points.filter((_,i) => i % 5 === 0).map((_,i) => {
      const ri = i * 5;
      return `<line x1="${xScale(ri)}" y1="${padY}" x2="${xScale(ri)}" y2="${padY+innerH}" stroke="var(--border)" stroke-width="1"/>
              <text x="${xScale(ri)}" y="${H-4}" text-anchor="middle" class="dem-label">${ri}</text>`;
    }).join("")}
    <text x="8" y="${yScale(maxE)}" class="dem-label">${Math.round(maxE)}m</text>
    <text x="8" y="${yScale(minE)}" class="dem-label">${Math.round(minE)}m</text>
    ${points.map((p,i) => {
      const col = gradesColor[i];
      return `<circle cx="${xScale(i)}" cy="${yScale(p.elevation)}" r="3" fill="${col}" opacity="0.7">
        <title>${p.elevation}m · grade ${p.grade}%</title>
      </circle>`;
    }).join("")}
  </svg>
  <div style="display:flex;gap:16px;font-size:10px;font-family:var(--mono);color:var(--muted);padding-top:8px">
    <span style="color:#2ECC71">● &lt;3% grade</span>
    <span style="color:#F5A623">● 3–6% grade</span>
    <span style="color:#E94560">● &gt;6% grade</span>
  </div>`;
}

// ── FUEL AUDIT ────────────────────────────────────────────────────────────────
async function loadAuditDashboard() {
  const data = await apiFetch("/api/fuel-audit/dashboard");
  if (!data) return;
  renderAuditDashboard(data);
}

function renderAuditDashboard(data) {
  const el = document.getElementById("audit-dashboard");
  if (!el) return;
  const s = data.fleet_summary;
  el.innerHTML = `
    <div class="hero-stats" style="grid-template-columns:repeat(5,1fr)">
      <div class="stat-card"><div class="stat-icon">👤</div><div class="stat-value">${s.total_riders}</div><div class="stat-label">Riders</div></div>
      <div class="stat-card"><div class="stat-icon">⛽</div><div class="stat-value">${fmt(s.total_fuel_l)}</div><div class="stat-label">Total Litres</div></div>
      <div class="stat-card accent"><div class="stat-icon">📊</div><div class="stat-value">${fmt(s.avg_efficiency)}</div><div class="stat-label">Avg km/L</div></div>
      <div class="stat-card"><div class="stat-icon">💰</div><div class="stat-value">${(s.total_cost_ugx/1e6).toFixed(1)}M</div><div class="stat-label">Total Cost UGX</div></div>
      <div class="stat-card"><div class="stat-icon">⚠</div><div class="stat-value">${s.anomaly_count}</div><div class="stat-label">Anomalies</div></div>
    </div>
    <div class="panel">
      <div class="panel-header"><span class="panel-title">Rider Fuel Efficiency Ranking</span><span class="panel-badge">Top 20</span></div>
      <div style="overflow-x:auto">
        <table class="fuel-table">
          <thead><tr>
            <th>#</th><th>Rider ID</th><th>km/L</th><th>Litres</th><th>Distance</th><th>Cost</th><th>Anomalies</th><th>Trend</th>
          </tr></thead>
          <tbody>
            ${data.riders.slice(0,20).map((r,i) => `<tr>
              <td style="color:var(--muted)">${i+1}</td>
              <td style="font-weight:700">${r.rider_id}</td>
              <td style="color:${r.efficiency_kpl >= 40 ? "#2ECC71" : r.efficiency_kpl >= 30 ? "#F5A623" : "#E94560"};font-weight:700">${fmt(r.efficiency_kpl)}</td>
              <td>${fmt(r.liters)}</td>
              <td>${fmt(r.distance_km)} km</td>
              <td>${fmtUGX(r.cost_ugx)}</td>
              <td>${r.anomalies > 0 ? `<span class="anomaly-flag">⚠ ${r.anomalies}</span>` : '<span style="color:var(--green)">✓</span>'}</td>
              <td class="${r.trend === "improving" ? "trend-up" : r.trend === "worsening" ? "trend-down" : ""}">${r.trend}</td>
            </tr>`).join("")}
          </tbody>
        </table>
      </div>
    </div>`;

  // Set today's date in form
  const dateEl = document.getElementById("a-date");
  if (dateEl) dateEl.value = new Date().toISOString().split("T")[0];
}

async function submitFuelEntry() {
  const body = {
    rider_id:    document.getElementById("a-rider").value,
    date:        document.getElementById("a-date").value,
    liters:      +document.getElementById("a-liters").value,
    cost_ugx:    +document.getElementById("a-cost").value,
    distance_km: +document.getElementById("a-dist").value,
    station:     document.getElementById("a-station").value,
  };
  toast("Submitting entry…");
  const data = await post("/api/fuel-audit/submit", body);
  if (!data) return;
  show("audit-entry-result");
  document.getElementById("audit-entry-result").innerHTML = `
    <div class="result-grid" style="grid-template-columns:repeat(3,1fr)">
      <div class="result-kv"><span class="rk">Efficiency</span><span class="rv">${fmt(data.avg_efficiency_kpl)} km/L</span></div>
      <div class="result-kv"><span class="rk">Trend</span><span class="rv ${data.trend === "improving" ? "green" : data.trend === "worsening" ? "red" : ""}">${data.trend}</span></div>
      <div class="result-kv"><span class="rk">Fleet Rank</span><span class="rv">${fmt(data.rank_percentile)}%ile</span></div>
    </div>
    ${data.anomalies.length ? `<div class="recommendation" style="border-color:rgba(233,69,96,.25)">⚠ ${data.anomalies.join(" · ")}</div>` : '<div class="recommendation">✓ No anomalies detected in this entry.</div>'}`;
}

// ── PILOT ──────────────────────────────────────────────────────────────────────
async function loadPilot() {
  const [stats, riders] = await Promise.all([
    apiFetch("/api/pilot/stats"),
    apiFetch("/api/pilot/riders"),
  ]);
  if (stats) renderPilotStats(stats);
  if (riders) renderPilotRiders(riders.riders);
}

function renderPilotStats(s) {
  const el = document.getElementById("pilot-stats-cards");
  if (!el) return;
  el.innerHTML = `
    <div class="stat-card accent"><div class="stat-icon">✦</div><div class="stat-value">${s.total_riders}</div><div class="stat-label">Total Enrolled</div></div>
    <div class="stat-card"><div class="stat-icon">▶</div><div class="stat-value">${s.active_riders}</div><div class="stat-label">Active Riders</div></div>
    <div class="stat-card"><div class="stat-icon">⭐</div><div class="stat-value">${fmt(s.avg_score)}</div><div class="stat-label">Avg Score</div></div>
    <div class="stat-card"><div class="stat-icon">⛽</div><div class="stat-value">${fmt(s.fuel_saved_liters)}</div><div class="stat-label">Litres Saved</div></div>`;

  const lb = document.getElementById("pilot-leaderboard");
  if (!lb) return;
  lb.innerHTML = `<table class="leaderboard-table">
    <thead><tr><th>Rank</th><th>Name</th><th>SACCO</th><th>Score</th><th>km/L</th></tr></thead>
    <tbody>
      ${s.leaderboard.map(r => `<tr>
        <td><span class="rank-badge rank-${r.rank <= 3 ? r.rank : "n"}">${r.rank}</span></td>
        <td style="font-weight:600">${r.name}</td>
        <td style="color:var(--text2);font-size:11px">${r.sacco}</td>
        <td>
          ${fmt(r.score)}
          <span class="score-bar"><span class="score-fill" style="width:${r.score}%"></span></span>
        </td>
        <td style="color:${r.kpl >= 40 ? "#2ECC71" : "#F5A623"}">${fmt(r.kpl)}</td>
      </tr>`).join("")}
    </tbody>
  </table>`;
}

function renderPilotRiders(riders) {
  const el = document.getElementById("pilot-riders");
  if (!el) return;
  el.innerHTML = `<div class="rider-list">
    ${riders.slice(0,15).map(r => `
      <div class="rider-card">
        <div class="rider-avatar">${r.name.split(" ").map(w=>w[0]).join("").slice(0,2)}</div>
        <div class="rider-info">
          <div class="rider-name">${r.name}</div>
          <div class="rider-meta">${r.rider_id} · ${r.sacco} · ${r.trips_count} trips</div>
        </div>
        <div>
          <div class="status-pill status-${r.status}">${r.status}</div>
          <div style="font-family:var(--mono);font-size:10px;color:var(--text2);text-align:center;margin-top:4px">${fmt(r.avg_fuel_kpl)} km/L</div>
        </div>
      </div>`).join("")}
  </div>`;
}

// ── BOOT ───────────────────────────────────────────────────────────────────────
document.addEventListener("DOMContentLoaded", () => {
  applyTheme();
  showView("dashboard");
});
